package torresdehanoi.simulacion;

public class Logica {

    public static void main(String args[]) {
        VentanaSimulacion ventanaSimulacion = new VentanaSimulacion();

    }
    
}